package com.awer.futbol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutbolApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutbolApiApplication.class, args);
	}

}
